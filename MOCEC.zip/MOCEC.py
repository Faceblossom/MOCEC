import numpy as np
import copy
import matplotlib.pyplot as plt


def GetSa(A):
    l = np.size(A, 0)
    Ad = A + np.eye(l)
    Sa = np.zeros([l, l]) 
    for i in range(l):
        Si = np.where(Ad[i, :] == 1)[0]
        for j in range(l):
            if i != j:
                Sj = np.where(Ad[j, :] == 1)[0]
                a = np.intersect1d(Si, Sj)
                Sa[i][j] = np.size(a) 
    return Sa


def CulF(A, compet1, compet2, f):
    A_c = copy.deepcopy(A)
    A_c[compet1, :] = A_c[compet1, :] + f
    A_c[:, compet1] = A_c[:, compet1] + f
    D = np.zeros([l, l])
    for i in range(l):
        D[i,i] = np.sum(A_c[i]) + 1
    W = np.dot(np.linalg.inv(D), A_c)
    c = copy.deepcopy(W[:, [compet1, compet2]])
    c = copy.deepcopy(np.delete(c, [compet1, compet2], 0))
    W = copy.deepcopy(np.delete(W, [compet1, compet2], 0))
    W = copy.deepcopy(np.delete(W, [compet1, compet2], 1))
    I = np.ones([l - 2])
    I = np.diag(I)
    X = np.dot(np.dot(np.linalg.inv(I - W), c), np.array([1, -1]))
    F = np.sum(np.sign(X))    
    return F


def CulG(A, compet1, compet2, f):
    A_c = copy.deepcopy(A)
    A_c[compet1, :] = A_c[compet1, :] + f
    A_c[:, compet1] = A_c[:, compet1] + f
    D = np.zeros([l, l])
    for i in range(l):
        D[i, i] = np.sum(A_c[i])
    c = copy.deepcopy(A_c[:, [compet1, compet2]])
    c = copy.deepcopy(np.delete(c, [compet1, compet2], 0))
    A_agent = copy.deepcopy(np.delete(A_c, [compet1, compet2], 0))
    A_agent = copy.deepcopy(np.delete(A_agent, [compet1, compet2], 1))
    D_agent = copy.deepcopy(np.delete(D, [compet1, compet2], 0))
    D_agent = copy.deepcopy(np.delete(D_agent, [compet1, compet2], 1))  
    X = np.dot(np.dot(np.linalg.inv(D_agent - A_agent), c), np.array([1, -1]))
    G = np.sum(np.sign(X))
    return G


if __name__ == '__main__':
    
    func = 1 # 1:"F"; 2:"G"
    method = 1 # 1:"MOCEC"; 2:"PO"; 3:"MOCEC-Cross"
    network = 1
    if network == 1:
        A = np.loadtxt(r'C:\Users\LYL\Desktop\MOCEC\Data\ZKC-A.txt')
        compet1 = 0
        compet2 = 33
    if network == 2:
        A = np.loadtxt(r'C:\Users\LYL\Desktop\MOCEC\Data\BD-A.txt')
        compet1 = 7
        compet2 = 14
    if network == 3:
        A = np.loadtxt(r'C:\Users\LYL\Desktop\MOCEC\Data\HS-A.txt')
        compet1 = 11
        compet2 = 45        
    if network == 4:       
        A = np.loadtxt(r'C:\Users\LYL\Desktop\MOCEC\Data\PB-A.txt')
        compet1 = 6
        compet2 = 84

    compet1_ne = np.where(A[compet1,:] == 1)[0]
    compet2_ne = np.where(A[compet2,:] == 1)[0]
    compet2_ne = np.setdiff1d(compet2_ne, compet1)
    compet2_ne = np.setdiff1d(compet2_ne, compet1_ne)
    Sa = GetSa(A)
    Sa_compet2 = copy.deepcopy(Sa[compet2][:])
    compet2_sim = np.where(Sa_compet2 != 0)[0]
    compet2_sim = np.setdiff1d(compet2_sim, compet1)
    compet2_sim = np.setdiff1d(compet2_sim, compet1_ne)
    l = np.size(A, 0)
    cand = np.arange(0, l, 1)
    cand = np.setdiff1d(cand,compet1)
    cand = np.setdiff1d(cand,compet2)
    cand = np.setdiff1d(cand,compet1_ne)
    f_10, f_20 = [], []    
    initial = np.zeros([l])
    if func == 1: initial_f = CulF(A, compet1, compet2, initial)
    if func == 2: initial_f = CulG(A, compet1, compet2, initial)
    S = [[initial, 0, initial_f]]
    T = int((np.size(compet2_ne) + 1) * (np.size(compet2_ne) + 2) * np.size(compet2_sim) * 2.718)
    
    for t in range(T):
        f = np.zeros([l]) 
        s = S[np.random.randint(len(S))]
        while True:
            if method == 1:
                for n in compet2_sim:
                    if np.random.random() < 1 / np.size(compet2_sim): f[n] = copy.deepcopy(1 - s[0][n])
                    else: f[n] = copy.deepcopy(s[0][n])
            if method == 2:
                for n in cand:
                    if np.random.random() < 1 / np.size(compet2_sim): f[n] = copy.deepcopy(1 - s[0][n])
                    else: f[n] = copy.deepcopy(s[0][n])                
            if np.sum(f) <= np.size(compet2_ne): break
        if method == 3:
            cross_point = np.random.randint(0, l)
            f[0: cross_point] = s[0][0: cross_point]
        if func == 1: F = CulF(A,compet1,compet2,f)
        if func == 2: F = CulG(A,compet1,compet2,f)
        ls = len(S)
        flag = 0
        i = 0
        while i < ls:
            if S[i][1] >= np.sum(f) and S[i][2] <= F:
                del S[i]
                flag = 1
                ls -= 1
                i -= 1
            i += 1
        if flag == 1: S.append([f, np.sum(f), F])
        else:
            ls = len(S)
            count = 0
            j = 0
            while j < ls:
                if (S[j][1] < np.sum(f) and S[j][2] < F) or (S[j][1] > np.sum(f) and S[j][2] > F):
                    count += 1
                j += 1
            if count == ls: S.append([f, np.sum(f), F])
        if network == 4:
            for k in range(len(S)):
                if S[k][1] == 10: f_10.append([t, S[k][2]])
                elif S[k][1] == 20: f_20.append([t, S[k][2]])       
        print("The current generation is %d" % (t + 1))
        
    ls = len(S)
    x, y = np.zeros([ls]), np.zeros([ls])
    for i in range(ls):
        x[i], y[i] = S[i][1], S[i][2]
    plt.plot(x,y,'.')
    plt.title('f')
    plt.show
    
    #np.savetxt('MOCEC-GRQC.txt', np.append(x,y).reshape(2,np.size(x)).T, fmt = "%d")
    #np.savetxt('MOCEC-PB-10.txt', np.array(f_10), fmt = "%d")
    #np.savetxt('MOCEC-PB-20.txt', np.array(f_20), fmt = "%d")
